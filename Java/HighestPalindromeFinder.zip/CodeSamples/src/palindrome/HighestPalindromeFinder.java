package palindrome;

public class HighestPalindromeFinder {
	
	/*
	 * This piece of code finds the highest multiple of n digit
	 * To save on run time it:
	 * - Scales with the amount of digits being multiplied
	 * - Only tests odd multiples of 11
	 * - Only multiplies unique number combinations
	 */

	public static void main(String[] args) {
		
		String limitString = "1";
		String startString = "1";
		String reducerString ="0.";
		
	    int  input = 8; //This is the number of digits
	    double reducer;
	    long start = 0, limit, x, y, z, out = 0;;
	    
	    boolean pal = false;
	    
	    //Create the number based on input (this will allow for the scaling to different digit sizes)
	    for(int i=0; i < input; i++){
	    	limitString += "0";
	    	startString += "0";
	    	
	    	if(i+1 > 2 && (i+1)%2 == 0) {//Increases the reducer based on the amount of digits, at a rate of 1 every 2 digits over 2
	    	reducerString += "0";
	    	}
	    }
	    reducerString += "1";
	    
	    //Convert it to the appropriate types
	    reducer = Double.parseDouble(reducerString);
	    limit = Long.parseLong(limitString);
	    start = Long.parseLong(startString);
	    
	    //Make start odd & reduce it
	    start = 1+(start - (long) (start*reducer));
	        
	    x = start;
	    y = start;
	    z = 0;
	    
	    //Goes through every unique x & y pair, and tests odd multiples of 11.
	    while(x < limit) {
	    	pal = false;
	    	y = start;
	    	
	    	while(y < limit) {
				if(x>y) {
					z = x*y;
				}
	    		if(z%11 == 0) {
	    			pal = palChecker(z);
	    			if(pal == true) {
	    				out = z;
	    			}
	    		}
	    		y+=2;
	    	}
			x+=2; //increments by 2 to check only odds
	    }
	    
	    System.out.println("Highest Palindrome of two "+ input + " digit numbers: " + out);
	    System.exit(0);
	}
	
	//Checks that num & reverse num are the same
		public static boolean palChecker(long num) {
			long reverse=0,sum=0,temp;
			boolean palindrome = false;
	  
	        temp=num;    
	        while(num>0){    
	        reverse=num%10; 
	        sum=(sum*10)+reverse;    
	        num=num/10;    
	        }   
	        
	        if(temp==sum){
	        palindrome = true;
	        }else{    
	        palindrome = false;
	        }
			return palindrome;
		}

}
